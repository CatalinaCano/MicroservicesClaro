using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using System.Net;
using System.Text;

namespace Microservice_Clients
{
    public static class CreateClientURL
    {
        [FunctionName("create_client")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "create_client")] HttpRequest req)
        {

            try
            {
                // Parametros esperados dentro de la peticion en la URL
                string identification = req.Query["identification"];
                string name = req.Query["name"];
                string surname = req.Query["surname"];
                string address = req.Query["address"];
                string phone = req.Query["phone"];

                if (IsValid(identification) && IsValid(name) && IsValid(surname) && IsValid(address) && IsValid(phone))
                {
                    DBAdapter adapter = new DBAdapter();
                    Client cli = new Client();
                    cli.Identification = identification;
                    cli.NameClient = name;
                    cli.SurnameClient = surname;
                    cli.AddressClient = address;
                    cli.PhoneClient = phone;

                    int ans = adapter.CreateClient(cli);
                    if (ans > 0)
                    {
                        return new HttpResponseMessage(statusCode: HttpStatusCode.OK)
                        {
                            Content = new StringContent("Sucessfull Operation", Encoding.UTF8, "application/text")
                        };
                    }
                    else
                    {
                        return new HttpResponseMessage(statusCode: HttpStatusCode.BadRequest)
                        {
                            Content = new StringContent("Operation Failed", Encoding.UTF8, "application/text")
                        };
                    }
                }


                return new HttpResponseMessage(statusCode: HttpStatusCode.BadRequest)
                {
                    Content = new StringContent("Operation Failed", Encoding.UTF8, "application/text")
                };
            }
            catch (Exception ex)
            {

                return new HttpResponseMessage(statusCode: HttpStatusCode.BadRequest)
                {
                    Content = new StringContent("Operation Failed "+ ex.Message.ToString(), Encoding.UTF8, "application/text")
                };
            }


          

            

        }

        private static bool IsValid(String att)
        {
            return att.Length>0 ? true:false;
        }


    }
}
