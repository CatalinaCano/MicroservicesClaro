﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Microservice_Clients
{
    public class DBAdapter
    {



        private const string cadenaConectDb = "sql_conection";
        

        public string StringConnectionDb { get; set; }
        


        public DBAdapter()
        {
            StringConnectionDb = Environment.GetEnvironmentVariable(cadenaConectDb);
            
        }


   

        public int CreateClient(Client client)
        {
            using (var connection = new SqlConnection(StringConnectionDb))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO [dbo].[Client] ([identification_card] ,[name] ,[surname] ,[address] ,[phone]) VALUES (@identificacion,@name,@surname,@address,@phone)";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = query;

                        cmd.Parameters.Add("@identificacion", SqlDbType.NVarChar, 250).Value = client.Identification;
                        cmd.Parameters.Add("@name", SqlDbType.NVarChar, 250).Value = client.NameClient;
                        cmd.Parameters.Add("@surname", SqlDbType.NVarChar, 250).Value = client.SurnameClient;
                        cmd.Parameters.Add("@address", SqlDbType.NVarChar, 250).Value = client.AddressClient;
                        cmd.Parameters.Add("@phone", SqlDbType.NVarChar, 250).Value = client.PhoneClient;

                        int rowsAffected = cmd.ExecuteNonQuery();


                        connection.Close();
                        return rowsAffected;
                    }
                }
                catch (Exception ex)
                {
                    System.Console.WriteLine(ex.ToString());
                    return -1;

                }
                finally
                {
                    //Cierra la conexion
                    connection.Close();
                }
            }
        }
    } 
    

            
    }

