using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.Text;

namespace Microservice_Clients.Functions
{
    public static class GetClients
    {
        /**
         *  Metodo asincrono que controla la ejecucion de la funcion, es equivalente al MAIN
         *  y corresponde a un HttpTrigger
         * */
        [FunctionName("clients")]
        public static HttpResponseMessage Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "clients")] HttpRequest req)
        {
            // Variable que contiene una lista de clientes resultado de 
            // la funcion  getClients()
            DBAdapter operationsBD = new DBAdapter();

            var listClients = operationsBD.getClients();

            // Valida si la lista contine clientes y retorna un 
            // JSON con el listado de los clientes
            if (listClients.Count > 0)
            {
                string json = string.Empty;
                json = JsonConvert.SerializeObject(listClients);
                return new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };

            }
                       
            //Creacion del JSON de respuesta incorrecta
            var BadResponse = new { id = -1, name = "No existen clientes para mostrar" };
            //Serializacion del JSON
            var jsonBad = JsonConvert.SerializeObject(BadResponse);
            //Respueta BAD
            return new HttpResponseMessage(HttpStatusCode.NotFound)
            {
                Content = new StringContent(jsonBad, Encoding.UTF8, "application/json")
            };

        }


    }
}
