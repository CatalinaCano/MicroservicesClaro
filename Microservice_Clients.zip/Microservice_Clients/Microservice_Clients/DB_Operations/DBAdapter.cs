﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Microservice_Clients
{
    public class DBAdapter
    {



        private const string cadenaConectDb = "sql_conection";
        

        public string StringConnectionDb { get; set; }
        


        public DBAdapter()
        {
            StringConnectionDb = Environment.GetEnvironmentVariable(cadenaConectDb);
            
        }


   

        public int CreateClient(Client client)
        {
            using (var connection = new SqlConnection(StringConnectionDb))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO [dbo].[Client] ([identification_card] ,[name] ,[surname] ,[address] ,[phone]) VALUES (@identificacion,@name,@surname,@address,@phone)";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = query;

                        cmd.Parameters.Add("@identificacion", SqlDbType.NVarChar, 250).Value = client.Identification;
                        cmd.Parameters.Add("@name", SqlDbType.NVarChar, 250).Value = client.NameClient;
                        cmd.Parameters.Add("@surname", SqlDbType.NVarChar, 250).Value = client.SurnameClient;
                        cmd.Parameters.Add("@address", SqlDbType.NVarChar, 250).Value = client.AddressClient;
                        cmd.Parameters.Add("@phone", SqlDbType.NVarChar, 250).Value = client.PhoneClient;

                        int rowsAffected = cmd.ExecuteNonQuery();


                        connection.Close();
                        return rowsAffected;
                    }
                }
                catch (Exception ex)
                {
                    System.Console.WriteLine(ex.ToString());
                    return -1;

                }
                finally
                {
                    //Cierra la conexion
                    connection.Close();
                }
            }
        }

        public Client  getClientByID(string client_id)
        {

            Client objClient = new Client();
            using (var connection = new SqlConnection(StringConnectionDb))
            {
                connection.Open();
                var query = "SELECT [identification_card] ,[name] ,[surname] ,[address] ,[phone] FROM [dbo].[Client] WHERE identification_card = @identification_card";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;
                    cmd.Parameters.Add("@identification_card", SqlDbType.NVarChar, 250).Value = client_id;
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            try
                            {
                                
                                objClient.Identification = (string)reader["identification_card"];
                                objClient.NameClient = (string)reader["name"].ToString();
                                objClient.SurnameClient = (string)reader["surname"].ToString();
                                objClient.AddressClient = (string)reader["address"].ToString();
                                objClient.PhoneClient = (string)reader["phone"].ToString();
                                return objClient;

                            }
                            catch (Exception ex)
                            {
                                //Manejo de la excepción
                                System.Console.WriteLine(ex.ToString());
                            }

                        }

                    }
                }



                //Cierra la conexion
                connection.Close();
            }
            // Retorna una arreglo de clientes
            return objClient;

        }

        public Boolean updateClientById(string client_id, Client update)
        {

            string query = BuildQueryUpdate(client_id, update);
           using (var connection = new SqlConnection(StringConnectionDb))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;

                    if (query.Contains("name"))
                    {
                        cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = update.NameClient;
                    }

                    if (query.Contains("surname"))
                    {
                        cmd.Parameters.Add("@surname", SqlDbType.NVarChar).Value = update.SurnameClient;
                    }

                    if (query.Contains("address"))
                    {
                        cmd.Parameters.Add("@address", SqlDbType.VarChar).Value = update.AddressClient;
                    }

                    if (query.Contains("phone"))
                    {
                        cmd.Parameters.Add("@phone", SqlDbType.VarChar).Value = update.PhoneClient;
                    }

                    cmd.Parameters.Add("@identification_card", SqlDbType.VarChar).Value = client_id;
                    

                    int rowsAffected = cmd.ExecuteNonQuery();
                    connection.Close();

                    if (rowsAffected > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    
                }
               
            }
            

        }

        public  List<Client> getClients()
        {

            List<Client> result = new List<Client>();           

            using (var connection = new SqlConnection(StringConnectionDb))
            {
                connection.Open();
                var query = "SELECT [identification_card] ,[name] ,[surname] ,[address] ,[phone] FROM [dbo].[Client]";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            try
                            {

                                Client objClient = new Client();
                                objClient.Identification = (string)reader["identification_card"];
                                objClient.NameClient = (string)reader["name"].ToString();
                                objClient.SurnameClient = (string)reader["surname"].ToString();
                                objClient.AddressClient = (string)reader["address"].ToString();
                                objClient.PhoneClient = (string)reader["phone"].ToString();
                                result.Add(objClient);
                            }
                            catch (Exception ex)
                            {
                                //Manejo de la excepción
                                System.Console.WriteLine(ex.ToString());
                            }
                        }
                    }
                }
                //Cierra la conexion
                connection.Close();
            }
            // Retorna una arreglo de clientes
            return result;
        }


        public string BuildQueryUpdate(string client_id, Client updated)
        {
            string recordUpdate = "UPDATE [Client] SET  update_date = GETDATE(),";

            if (updated.NameClient != null && IsValid(updated.NameClient))
            {
                var columnName = "name";
                var sql = String.Format(@"{0} = @name, ", columnName);
                recordUpdate = String.Concat(recordUpdate, sql);

            }

            if (updated.SurnameClient != null && IsValid(updated.SurnameClient))
            {
                var columnName = "surname";
                var sql = String.Format(@"{0} = @surname, ", columnName);
                recordUpdate = String.Concat(recordUpdate, sql);
            }

            if (updated.AddressClient != null && IsValid(updated.AddressClient))
            {
                var columnName = "address";
                var sql = String.Format(@"{0} = @address, ", columnName);
                recordUpdate = String.Concat(recordUpdate, sql);
            }

            if (updated.PhoneClient != null && IsValid(updated.PhoneClient))
            {
                var columnName = "phone";
                var sql = String.Format(@"{0} = @phone, ", columnName);
                recordUpdate = String.Concat(recordUpdate, sql);
            }

            recordUpdate = recordUpdate.Remove(recordUpdate.LastIndexOf(','), 1);
            recordUpdate = String.Concat(recordUpdate, "WHERE identification_card = " + "@identification_card");

            return recordUpdate;
        }



        public Boolean deleteClientID(string client_id)
        {

            
            using (var connection = new SqlConnection(StringConnectionDb))
            {
                connection.Open();
                var query = "DELETE FROM [dbo].[Client] WHERE identification_card = @identification_card";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;
                    cmd.Parameters.Add("@identification_card", SqlDbType.NVarChar, 250).Value = client_id;
                    
                    int rowsAffected = cmd.ExecuteNonQuery();
                    connection.Close();


                    //Cierra la conexion
                    connection.Close();

                    if (rowsAffected > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }


                }
                


                
            }
       
       

        }


        public bool IsValid(string value)
        {
            if (value.Trim().Length > 0)
                return true;
            return false;
        }
    }



}

