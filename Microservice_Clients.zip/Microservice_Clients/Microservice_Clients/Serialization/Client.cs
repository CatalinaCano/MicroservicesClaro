﻿using Newtonsoft.Json;


namespace Microservice_Clients
{
    public class Client
    {
        [JsonProperty("identification")]
        public string Identification { get; set; }

        [JsonProperty("name")]
        public string NameClient { get; set; }

        [JsonProperty("surname")]
        public string SurnameClient { get; set; }

        [JsonProperty("address")]
        public string AddressClient { get; set; }

        [JsonProperty("phone")]
        public string PhoneClient { get; set; }

   
    }

    
}
