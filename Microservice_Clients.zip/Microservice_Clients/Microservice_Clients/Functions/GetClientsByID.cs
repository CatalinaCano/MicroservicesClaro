using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.Text;

namespace Microservice_Clients.Functions
{
    public static class GetClientsByID
    {
        /**
         *  Metodo asincrono que controla la ejecucion de la funcion, es equivalente al MAIN
         *  y corresponde a un HttpTrigger
         * */
        [FunctionName("clients_id")]
        public static HttpResponseMessage Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "clients_id/{client_id}")] HttpRequest req, string client_id)
        {


            if(client_id.Length > 0)
            {
                DBAdapter operationsBD = new DBAdapter();



                var client = operationsBD.getClientByID(client_id);
                string json = string.Empty;
                json = JsonConvert.SerializeObject(client);
                return new HttpResponseMessage(HttpStatusCode.OK)
                {
                        Content = new StringContent(json, Encoding.UTF8, "application/json")
                 };

            }

            return new HttpResponseMessage(HttpStatusCode.BadRequest)
            {
                Content = new StringContent("Bad Request, parameter id_client is necessary", Encoding.UTF8, "application /text")
            };
            

        }

    }
}
