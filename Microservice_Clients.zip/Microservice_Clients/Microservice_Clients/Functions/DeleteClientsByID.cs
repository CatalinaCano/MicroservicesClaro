using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.Text;

namespace Microservice_Clients.Functions
{
    public static class DeleteClientsByID
    {
        /**
         *  Metodo asincrono que controla la ejecucion de la funcion, es equivalente al MAIN
         *  y corresponde a un HttpTrigger
         * */
        [FunctionName("delete_client")]
        public static HttpResponseMessage Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "delete_client/{client_id}")] HttpRequest req, string client_id)
        {


            if(client_id.Length > 0)
            {
                DBAdapter operationsBD = new DBAdapter();


                if (operationsBD.deleteClientID(client_id)) {
                    return new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent("Sucessfull operation", Encoding.UTF8, "application/text")
                    };
                }
                else
                {
                    return new HttpResponseMessage(HttpStatusCode.Conflict)
                    {
                        Content = new StringContent("It's impossible to do this operation", Encoding.UTF8, "application/text")
                    };
                }
                
                

            }

            return new HttpResponseMessage(HttpStatusCode.BadRequest)
            {
                Content = new StringContent("Bad Request, parameter id_client is necessary", Encoding.UTF8, "application /text")
            };
            

        }

    }
}
