using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using System.Net;
using System.Text;
using Newtonsoft.Json;

namespace Microservice_Clients
{
    public static class CreateClientJSON
    {
        [FunctionName("create_client_json")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "create_client_json")] HttpRequest req)
        {

            // Lee la peticion realizada a la URL expuesta
            String requestBody = await new StreamReader(req.Body).ReadToEndAsync();

            //Valida que no sea null el cuerpo del requestBody
            if (!String.IsNullOrEmpty(requestBody))
            {
                try
                {
                    // Inicializa un objeto vacio
                    Client data = new Client();
                    // Deserealiza el objeto JSON para obtener los parametros
                    data = JsonConvert.DeserializeObject<Client>(requestBody);

                    if (IsValid(data.Identification) && IsValid(data.NameClient) && IsValid(data.SurnameClient) && IsValid(data.AddressClient) && IsValid(data.PhoneClient))
                    {
                        DBAdapter adapter = new DBAdapter();
                        int ans = adapter.CreateClient(data);
                        if (ans > 0)
                        {
                            return new HttpResponseMessage(statusCode: HttpStatusCode.OK)
                            {
                                Content = new StringContent("Sucessfull Operation", Encoding.UTF8, "application/text")
                            };
                        }
                        else
                        {
                            return new HttpResponseMessage(statusCode: HttpStatusCode.BadRequest)
                            {
                                Content = new StringContent("Operation Failed", Encoding.UTF8, "application/text")
                            };
                        }

                    }
                    else
                    {
                        return new HttpResponseMessage(statusCode: HttpStatusCode.BadRequest)
                        {
                            Content = new StringContent("Operation Failed", Encoding.UTF8, "application/text")
                        };
                    }

                }
                catch (Exception ex)
                {
                    return new HttpResponseMessage(statusCode: HttpStatusCode.BadRequest)
                    {
                        Content = new StringContent("Operation Failed "+ ex.ToString(), Encoding.UTF8, "application/text")
                    };
                }
            }
            else
            {
                return new HttpResponseMessage(statusCode: HttpStatusCode.BadRequest)
                {
                    Content = new StringContent("Operation Failed", Encoding.UTF8, "application/text")
                };
            }

        }

        private static bool IsValid(String att)
        {
            return att.Length>0 ? true:false;
        }


    }
}
