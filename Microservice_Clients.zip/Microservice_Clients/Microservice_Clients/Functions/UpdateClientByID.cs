using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.Text;

namespace Microservice_Clients.Functions
{
    public static class UpdateClientByID
    {
        /**
         *  Metodo asincrono que controla la ejecucion de la funcion, es equivalente al MAIN
         *  y corresponde a un HttpTrigger
         * */
        [FunctionName("update_client")]
        public static async Task<HttpResponseMessage> RunAsync(
            [HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = "update/{client_id}")] HttpRequest req, string client_id)
        {

            String requestBody = await new StreamReader(req.Body).ReadToEndAsync();



            if (client_id.Length > 0 && !String.IsNullOrEmpty(requestBody))
            {
                DBAdapter operationsBD = new DBAdapter();            
                Client data = new Client();
                // Deserealiza el objeto JSON para obtener los parametros
                data = JsonConvert.DeserializeObject<Client>(requestBody);


                if (operationsBD.updateClientById(client_id, data))
                {
                    return new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent("Successful operation", Encoding.UTF8, "application/text")
                    };
                }
                else
                {
                    return new HttpResponseMessage(HttpStatusCode.NotFound)
                    {
                        Content = new StringContent("It's impossible to do this operation", Encoding.UTF8, "application/text")
                    };
                }

              
            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest)
                {
                    Content = new StringContent("Bad Request, parameter id_client is necessary", Encoding.UTF8, "application/text")
                };
            }


        }

    }
}
